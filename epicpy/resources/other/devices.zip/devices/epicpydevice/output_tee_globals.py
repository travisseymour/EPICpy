from epiclibcpp.epiclib.output_tee_globals import (Normal_out, Trace_out, Exception_out, Debug_out, Device_out)
