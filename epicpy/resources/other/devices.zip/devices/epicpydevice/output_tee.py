import sys

import epicpy.epiclib.epiclib

class Output_tee(epicpy.epiclib.epiclib.Output_tee):
    """
    The Output_tee class allows you to split output among as many output streams
    and View_bases as you wish.  It keeps a list of pointers to ostream objects and View_bases,
    and overloads operator<< to output to each stream in the list, and to an internal
    ostringstring object whose contents are written a line-at-a-time to each View_base.

    This class assumes the pointed-to stream objects and View_bases exist.
    If the stream object or View_base is deallocated, it should first be taken out of the list.
    No check is made for putting the same stream or View_base in the list more than once.

    Note that the ostringstream object is always present, but is only written to or manipulated if
    there are View_bases in the list.
    """

    # Methods omitted here, if you need them check Output_tee.h in EPICLib codebase

    def __new__(cls, *args, **kwargs):
    #     return epicpy.epiclib.epiclib.Output_tee(*args, **kwargs)
        raise NotImplementedError('You should not be creating Output_tee instances. This class is here only for typing purposes in method signatures.')


if __name__ == '__main__':
    ot = Output_tee()
    help(ot)