import textwrap
from typing import Any

from pathlib import Path
from enum import Enum, auto
import random
from datetime import datetime

from epicpydevice import epicpy_device_base
from epicpydevice.output_tee import Output_tee
from epicpydevice.epic_statistics import Mean_accumulator
from epicpydevice.symbol_utilities import concatenate_to_Symbol, get_nth_Symbol
from epicpydevice.device_exception import Device_exception
from epicpydevice.speech_word import Speech_word
import epicpydevice.geometric_utilities as GU
from epicpydevice.symbol import Symbol
from epicpydevice.standard_symbols import (
    Red_c,
    Green_c,
    Blue_c,
    Yellow_c,
    Black_c,
    Text_c,
    Color_c,
    Shape_c,
    Circle_c,
)

import pingouin as pg
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.legend_handler import HandlerTuple


class state(Enum):
    START = auto()
    START_TRIAL = auto()
    PRESENT_FIXATION = auto()
    REMOVE_FIXATION = auto()
    PRESENT_STIMULUS = auto()
    WAITING_FOR_RESPONSE = auto()
    DISCARD_STIMULUS = auto()
    FINISH_TRIAL = auto()
    SHUTDOWN = auto()


USING_OLDER_EPICLIB = False

# EpicPy will expect all devices to be of class "EpicDevice" and subclassed from
# "EpicPyDevice" or "epicpy_device.EpicPyDevice"


class EpicDevice(epicpy_device_base.EpicPyDevice):
    def __init__(self, ot: Output_tee, parent: Any, device_folder: Path):
        epicpy_device_base.EpicPyDevice.__init__(
            self,
            parent=parent,
            ot=ot,
            device_name="Choice_Device_v2022.3",
            device_folder=device_folder,
        )

        # NOTE: ot is not being used, just use self.write(...)
        self.device_name = "Choice_Device_v2022.3"
        self.condition_string = "10 4 Hard Draft"  # from EpicPyDevice, default is ''
        self.n_trials = 10
        self.color_count = 4
        self.task_difficulty = "Hard"
        self.tag_str = "Draft"

        # differentiator in case this data is combined with Detection data
        self.task_name = "Choice"

        self.trial = 0
        self.run_id = self.unique_id()

        self.current_vrt = Mean_accumulator()

        # EPIC Simulation controller will know device is finished when
        #   self.state == self.SHUTDOWN
        self.state = state.START  # from EpicPyDevice, default is 0
        self.SHUTDOWN = state.SHUTDOWN  # from EPICPyDevice, default is 1000

        self.vresponse_made = False
        self.vstims = [Red_c, Green_c, Blue_c, Yellow_c]
        self.vresps = [Symbol("U"), Symbol("I"), Symbol("O"), Symbol("P")]
        self.vstimresp = list(zip(self.vstims, self.vresps))
        self.vstim_color = None
        self.correct_vresp = None
        self.vstim_name = None
        self.vstim_xloc = None
        self.vstim_onset = 0

        self.reparse_conditionstring = False  # from EpicPyDevice, default is False

        # device constants
        self.Warning_c = Symbol("#")
        self.VWarn_c = Symbol("Fixation")
        self.VStim_c = Symbol("Stimulus")
        self.ColorWord_c = Symbol("ColorWord")
        self.Center_screen_c = Symbol("Center_screen")

        # experiment constants
        self.wstim_location_c = GU.Point(0.0, 0.0)
        self.wstim_size_c = GU.Size(1.0, 1.0)
        self.vstim_size_c = GU.Size(2.0, 2.0)
        self.intertrialinterval_c = 5000

        # Optionally expose some boolean device options to the user via the GUI.
        self.option = dict()  # from EpicPyDevice, default is dict()
        # useful for showing debug information during development
        self.option["show_debug_messages"] = True
        # useful for showing device state info during trial run
        self.option["show_trial_events"] = True
        # useful for outputting trial parameters and data during task run
        self.option["show_trial_data"] = True
        # useful for long description of the task and parameters
        self.option["show_task_description"] = True
        # useful for timing runs
        self.option["show_task_statistics"] = True

        # a datafile is automatically managed by EpicPyDevice.
        # Use self.data_writer.writerow(TUPLE OF VALUES) to write each row of csv data.
        # Need to first define the data header or your csv file could be malformed:
        self.data_header = (
            "RunID",
            "Trial",
            "Task",
            "Difficulty",
            "StimColor",
            "StimPos",
            "CorrectResponse",
            "Response",
            "Modality",
            "RT",
            "Accuracy",
            "Tag",
            "Device",
            "Rules",
            "Date",
        )

        # # assumes device file is next to folder called images!
        # self.show_view_background(
        #     view_type="visual", file_name="donders_monitor.png", scaled=True
        # )
        # self.show_view_background(
        #     view_type="auditory", file_name="donders_tones.png", scaled=True
        # )

        if self.option["show_task_description"]:
            self.describe_task()
    def parse_condition_string(self):
        error_msg = (
            f"{self.condition_string}\n Should be: space-delimited "
            f"trials(int > 0) colors(1-4) difficulty(Easy or Hard) "
            f"tag(any string)"
        )

        # returns items from space delimited condition string as strings.
        # Uses self.get_param_list() instead of self.condition_string.split(' ') to
        # ensure any accidentally remaining range information is ignored.
        params = self.get_param_list()

        try:
            assert len(params) == 4, "Incorrect condition string: "
            trials, colors, difficulty, tag = params
            difficulty = difficulty.lower()
            trials = int(trials) if str(trials).isdigit() else 0
            colors = int(colors) if str(colors).isdigit() else 0
            assert trials > 0, "Number of trials must be positive: "
            assert 1 <= colors <= 4, "Colors must be between 1 and 4"
            assert difficulty in (
                "easy",
                "hard",
            ), "Task difficulty must be 'Easy' or 'Hard'"
        except AssertionError as e:
            raise Device_exception(f"Error Parsing the Condition String: {e} | {error_msg}")

        self.color_count = colors
        self.n_trials = trials
        self.task_difficulty = difficulty
        self.tag_str = tag

        self.reparse_conditionstring = False

    def initialize(self):
        """
        Initializes run. Called whenever model is stopped and started anew.
        I.e., NOT called, when model is paused and resumed.
        """
        self.vresponse_made = False
        self.trial = 0
        self.run_id = self.unique_id()
        self.state = state.START
        self.current_vrt.reset()

        # from EpicPyDevice, recommended for your initialize method!
        self.init_data_output()

    def describe_task(self):
        description = f"""
        ******************************************************************
        f"Initializing Device: {self.device_name.replace('_', ' ')} 
        f"Current Parameter String: {self.condition_string}
        ******************************************************************
        
        Events
        ------
         - Trial Start
         - Warning Signal (Simultaneous Visual and Auditory)
           Visual: "#" (1000 ms)
           Auditory: 'Beep' for 300 ms & 
         - Blank Screen (500-1300 ms random)
         - Stimulus (Simultaneous Visual and Auditory) for 500 ms
           Visual: Red, Green, Blue, or Yellow filled circle 
           Auditory: "Ding", "Dong", "Bing", or "Bong"
         - Waits for keyboard button press or vocal utterance
           Correct Responses
           Keyboard: U,I,O,P for R,G,B,Y, respectively
           Vocal: "U","I","O","P" for R,G,B,Y, respectively
         - Inter-Trial Interval, Blank Screen, for 5000 ms
        
        Conditions:
        ----------
         - Easy: X position is at screen center (x = 0)
         - Hard: X position randomly selected from [-2, -1, 0, 1, 2]
        
        Parameter String:
        ----------------
         - Structure: TRIALS NUM_COLORS DIFFICULTY TAG
         - Values: Trials: Integer > 0 
                   Num Colors: Integer 1-4
                   Difficulty: Easy or Hard
                   Tag: Any Word (simply added to TAG column in data file)
         - Default: 10 4 Hard Draft
        ******************************************************************
        """
        self.write(textwrap.dedent(description))

    def handle_Start_event(self):
        """
        You have to get the ball rolling with a first time-delayed event,
        nothing happens until you do.
        """
        self.schedule_delay_event(500)

    def handle_Stop_event(self):
        """
        called after the stop_simulation function (which is part of the base device class)
        """
        self.write(f"{self.processor_info()} received Stop_event\n")
        self.finalize_data_output()  # from EpicPyDevice, recommended
        self.refresh_experiment()

    def handle_Delay_event(
        self,
        _type: Symbol,
        datum: Symbol,
        object_name: Symbol,
        property_name: Symbol,
        property_value: Symbol,
    ):

        global DEVICE_FINISHED
        if self.state == state.START:
            if self.option["show_trial_events"]:
                self.write("********-->STATE: START\n")
            self.state = state.START_TRIAL
            self.schedule_delay_event(500, Symbol('StartTrial'), Symbol())
        elif self.state == state.START_TRIAL and _type==Symbol('StartTrial'):
            if self.option["show_trial_events"]:
                self.write("********-->STATE: START_TRIAL\n")
            self.vresponse_made = False
            self.start_trial()
            self.state = state.PRESENT_FIXATION
            self.schedule_delay_event(100, Symbol('PresentFixation'), Symbol())
        elif self.state == state.PRESENT_FIXATION and _type==Symbol('PresentFixation'):
            if self.option["show_trial_events"]:
                self.write("********-->STATE: PRESENT_FIXATION\n")
            self.present_fixation_point()
            self.state = state.REMOVE_FIXATION
            self.schedule_delay_event(1000, Symbol('RemoveFixation'), Symbol())
        elif self.state == state.REMOVE_FIXATION and _type==Symbol('RemoveFixation'):
            if self.option["show_trial_events"]:
                self.write("********-->STATE: REMOVE_FIXATION\n")
            self.remove_fixation_point()
            self.state = state.PRESENT_STIMULUS
            stimwaittime = random.randint(800, 1300)
            self.schedule_delay_event(stimwaittime, Symbol('PresentStimulus'), Symbol())
        elif self.state == state.PRESENT_STIMULUS:
            if self.option["show_trial_events"]:
                self.write("********-->STATE: PRESENT_STIMULUS\n")
            self.present_stimulus()
            self.state = state.WAITING_FOR_RESPONSE
            self.schedule_delay_event(100, Symbol('WaitForResp'), Symbol())
        elif self.state == state.WAITING_FOR_RESPONSE and _type==Symbol('WaitForResp'):
            if self.option["show_trial_events"]:
                self.write("********-->STATE: WAITING_FOR_RESPONSE\n")
            # nothing to do, just wait
            # note: next state and schedule_delay_event sent by response handler!
        elif self.state == state.DISCARD_STIMULUS:
            if self.option["show_trial_events"]:
                self.write("********-->STATE: DISCARD_STIMULUS\n")
            self.remove_stimulus()
            self.state = state.FINISH_TRIAL
            self.schedule_delay_event(self.intertrialinterval_c,
                                      Symbol('FinishTrial'),
                                      Symbol())
        elif self.state == state.FINISH_TRIAL and _type==Symbol('FinishTrial'):
            if self.option["show_trial_events"]:
                self.write("********-->STATE: FINISH_TRIAL\n")
            self.setup_next_trial()
        elif self.state == state.SHUTDOWN:
            if self.option["show_trial_events"]:
                self.write("********-->STATE: SHUTDOWN\n")
            self.stop_simulation()  # doesn't do anything in EpicPy...could just omit
        else:
            raise Device_exception( f"Device delay event in unknown or improper device state: {self.state}")

    def start_trial(self):
        if self.option["show_debug_messages"]:
            self.write("*trial_start|")

        if self.reparse_conditionstring:
            self.parse_condition_string()
            self.initialize()

        self.trial += 1

        if self.option["show_debug_messages"]:
            self.write("trial_start*\n")

    def present_fixation_point(self):
        if self.option["show_debug_messages"]:
            self.write("*present_fixation|")

        self.wstim_v_name = concatenate_to_Symbol(self.VWarn_c, self.trial)
        self.make_visual_object_appear(
            self.wstim_v_name, self.wstim_location_c, self.wstim_size_c
        )
        self.set_visual_object_property(self.wstim_v_name, Text_c, self.Warning_c)
        self.set_visual_object_property(self.wstim_v_name, Color_c, Black_c)

        # no need to keep ref, sound will remove itself after a delay
        wstim_snd_name = concatenate_to_Symbol("WarningSound", self.trial)
        self.make_auditory_sound_event(
            wstim_snd_name, Symbol("Signal"), GU.Point(0, -5), Symbol("Beep"), 12, 300
        )

        wstim_snd_name = Symbol(f"WarningSpeech{self.trial}")

        warning_word = Speech_word(
            name=wstim_snd_name,
            stream_name=Symbol("ComputerSpeaker"),
            time_stamp=self.get_time(),
            location=GU.Point(0, -10),
            pitch=16.0,
            loudness=13.0,
            duration=500.0,
            level_left=1.0,
            level_right=1.0,
            content=Symbol("Warning"),
            speaker_gender=Symbol("Any"),
            speaker_id=Symbol("Computer"),
            utterance_id=100
        )

        self.make_auditory_speech_event(warning_word)

        if self.option["show_debug_messages"]:
            self.write("present_fixation*\n")

    def remove_fixation_point(self):
        if self.option["show_debug_messages"]:
            self.write("*remove_fixation|")

        self.make_visual_object_disappear(self.wstim_v_name)

        if self.option["show_debug_messages"]:
            self.write("remove_fixation*\n")

    def present_stimulus(self):
        if self.option["show_debug_messages"]:
            self.write("*present_stimulus|")

        self.vstim_color, self.correct_vresp = random.choice(self.vstimresp)
        self.vstim_name = concatenate_to_Symbol(self.VStim_c, self.trial)

        if self.task_difficulty == "easy":
            self.vstim_xloc = 0.0
        else:
            self.vstim_xloc = random.choice((-2.0, -1.0, 0.0, 1.0, 2.0))

        self.make_visual_object_appear(
            self.vstim_name, GU.Point(self.vstim_xloc, 0.0), self.vstim_size_c
        )
        self.set_visual_object_property(self.vstim_name, Shape_c, Circle_c)
        self.set_visual_object_property(self.vstim_name, Color_c, self.vstim_color)

        self.vstim_onset = self.get_time()
        self.vresponse_made = False

        # no need to keep ref, sound will remove itself after a delay
        vstim_snd_name = concatenate_to_Symbol("StimulusSound", self.trial)
        stim_sound = {'Red': "Ding", 'Green': "Dong", 'Blue': "Bing", 'Yellow': "Bong"}

        self.make_auditory_sound_event(
            vstim_snd_name,
            Symbol("Signal"),
            GU.Point(0, 10),
            Symbol(stim_sound[str(self.vstim_color)]),
            12,
            500,
            500,
        )

        if self.option["show_debug_messages"]:
            self.write("present_stimulus*\n")

    def remove_stimulus(self):
        if self.option["show_debug_messages"]:
            self.write("*remove_stimulus|")

        self.make_visual_object_disappear(self.vstim_name)

        if self.option["show_debug_messages"]:
            self.write("remove_stimulus*\n")

    def setup_next_trial(self):
        if self.trial < self.n_trials:
            if self.option["show_debug_messages"]:
                self.write("*setup_next_trial|")
            self.state = state.START_TRIAL
            self.schedule_delay_event(300, Symbol('StartTrial'), Symbol())
            if self.option["show_debug_messages"]:
                self.write("setup_next_trial*\n")
        else:
            if self.option["show_debug_messages"]:
                self.write("*shutdown_experiment|")
            # things to do prior to shutdown
            self.finalize_data_output()  # from EpicPyDevice, recommended when task ends!
            self.show_output_stats()
            self.refresh_experiment()  # tidy up for subsequent runs

            # shutting down!
            self.state = self.SHUTDOWN
            self.schedule_delay_event(500)

            if self.option["show_debug_messages"]:
                self.write("shutdown_experiment*\n")

    def refresh_experiment(self):
        self.vresponse_made = False
        self.trial = 0
        self.state = state.START
        self.current_vrt.reset()

    def output_statistics(self):
        s = (
            f"Task Name: {self.task_name}  Task Difficulty: {self.task_difficulty}"
            f"  Trials Run: {self.trials}/{self.n_trials}\n"
        )
        self.write(s)

        s = f"N = {self.current_vrt.get_n()}, Mean RT = {self.current_vrt.get_mean()}"
        self.write(f"{s}\n(note: Mean excludes 1st trial)\n\n")

    def handle_Keystroke_event(self, key_name: Symbol):
        if self.vresponse_made:
            return

        if self.option["show_debug_messages"]:
            self.write("\n*handle_keystroke_event...\n")

        rt = self.get_time() - self.vstim_onset
        if key_name == self.correct_vresp:
            outcome = "CORRECT"
            if self.trial > 1:
                self.current_vrt.update(rt)
        else:
            outcome = "INCORRECT"

        if self.option["show_trial_data"]:
            # data display for normal output window
            s = (
                f"\nTrial: {self.trial} | Task: {self.task_name} | Difficulty: "
                f"{self.task_difficulty} | RT: {rt} | StimColor: {self.vstim_color} | "
                f"StimPos: {self.vstim_xloc} | Modality: Keyboard | "
                f"Response: {key_name} | CorrectResponse: {self.correct_vresp} | "
                f"Accuracy: {outcome}\n"
            )

            self.write(s)

        # real data saved to file
        if self.data_file:
            # note: order of values dictated by names in self.data_header
            data = (
                self.run_id,
                self.trial,
                self.task_name,
                self.task_difficulty,
                self.vstim_color,
                self.vstim_xloc,
                self.correct_vresp,
                key_name,
                "Keyboard",
                rt,
                outcome,
                self.tag_str,
                self.device_name,
                self.rule_filename,
                datetime.now().ctime(),
            )
            self.data_writer.writerow(data)

        self.vresponse_made = True

        if self.option["show_debug_messages"]:
            self.write("\nhandle_keystroke_event*\n")

        self.state = state.DISCARD_STIMULUS
        self.schedule_delay_event(500)

    def handle_Vocal_event(self, vocal_input: Symbol, duration: int = 0):
        if self.vresponse_made:
            return

        if self.option["show_debug_messages"]:
            self.write("\n*handle_vocal_event...\n")

        rt = self.get_time() - self.vstim_onset
        if vocal_input == self.correct_vresp:
            outcome = "CORRECT"
            if self.trial > 1:
                self.current_vrt.update(rt)
        else:
            outcome = "INCORRECT"

        if self.option["show_trial_data"]:
            # data display for normal output window
            s = (
                f"\nTrial: {self.trial} | Task: {self.task_name} | "
                f"Difficulty: {self.task_difficulty} | "
                f"RT: {rt} | StimColor: {self.vstim_color} | "
                f"StimPos: {self.vstim_xloc} | Modality: Vocal | "
                f"Response: {vocal_input} | CorrectResponse: {self.correct_vresp} | "
                f"Accuracy: {outcome}\n"
            )

            self.write(s)

        # real data saved to file
        if self.data_file:
            # note: order of values dictated by names in self.data_header
            data = (
                self.run_id,
                self.trial,
                self.task_name,
                self.task_difficulty,
                self.vstim_color,
                self.vstim_xloc,
                self.correct_vresp,
                vocal_input,
                "Voice",
                rt,
                outcome,
                self.tag_str,
                self.device_name,
                Path(self.rule_filename).name,
                datetime.now().ctime(),
            )
            self.data_writer.writerow(data)

        self.vresponse_made = True

        if self.option["show_debug_messages"]:
            self.write("\nhandle_vocal_event*\n")

        self.state = state.DISCARD_STIMULUS
        self.schedule_delay_event(500)

    def handle_Eyemovement_Start_event(
        self, target_name: Symbol, new_location: GU.Point
    ):
        ...

    def handle_Eyemovement_End_event(self, target_name: Symbol, new_location: GU.Point):
        ...

    def show_output_stats(self):
        # use pandas to load in data run so far (include all data from previous runs)
        # (assumes self.finalize_data_output() has been called)
        pd.set_option("display.precision", 3)
        data = pd.read_csv(self.data_filepath)

        # self.stats_write(f'Outcomes: {set(data.Accuracy)}')
        correct_data = data.query('Accuracy=="CORRECT"')
        correct_trials_N = len(correct_data.Accuracy)
        all_trials_N = len(data.Accuracy)
        mean_rt = correct_data.RT.mean() if correct_trials_N else None
        accuracy = ((correct_trials_N / all_trials_N) * 100) if all_trials_N else 0
        self.stats_write(
            f"N={all_trials_N}, "
            f"CORRECT={correct_trials_N} "
            f"INCORRECT={all_trials_N-correct_trials_N} "
            f'MEAN_RT={"NA" if mean_rt is None else int(mean_rt)} '
            f"ACCURACY={accuracy:0.2f}%"
        )

        if not self.option["show_task_statistics"]:
            return

        # note: show_output_stats_????() strips incorrect trials from local var data
        if "Difficulty" in data.columns and sorted(set(data["Difficulty"])) == [
            "easy",
            "hard",
        ]:
            self.show_output_stats_2way(data)
        else:
            self.show_output_stats_1way(data)

    def show_output_stats_1way(self, data: pd.DataFrame):
        try:
            data.query('Accuracy=="CORRECT"', inplace=True)

            colors = [str(vstim)[0] for vstim in self.vstims]
            colors = colors[: self.color_count]

            cond = str(data["Difficulty"][0]).title()

            self.stats_write(
                f"<h4>Choice Task<br>ANOVA: RT by StimColor<br>{colors}<br>{cond} "
                f"Condition.</h4>",
                color="Orange",
            )

            # display table
            try:
                table = data.groupby(["StimColor"])["RT"].agg(["mean", "count"])
                table = table.astype(int)
                self.stats_write(table.transpose())
            except Exception as e:
                self.stats_write(
                    f"Not enough data to create means table: {e}", color="Red"
                )

            # display anova results
            try:
                err_msg = "Data must contain StimColor with at least 2 colors."
                assert len(set(data.StimColor)) >= 2, err_msg
                err_msg = (
                    "For an ANOVA, the data must contain at least 3 RunIDs "
                    "from at least 3 separate runs."
                )
                assert len(set(data.RunID)) >= 3, err_msg

                aov = pg.rm_anova(data, dv="RT", subject="RunID", within="StimColor")

                # this is cosmetic for demo devices -- helps anova fit in smaller window
                for factor in ("p-GG-corr", "eps", "sphericity", "W-spher", "p-spher"):
                    if factor in aov.columns:
                        aov.drop([factor], axis=1, inplace=True)

                self.stats_write(aov)
            except AssertionError as e:
                self.stats_write(
                    f"Not enough data to run mixed-model anova: {e}", color="Red"
                )
            except Exception as e:
                self.stats_write(f"Unable to run mixed-model anova: {e}", color="Red")

            # create nice bar plot
            fig, ax = plt.subplots(figsize=(7, 4), dpi=96)
            sns.set(style="whitegrid", color_codes=True)
            sns.set_context("paper", font_scale=1.5)  # paper, notebook, talk, poster
            colors = [
                "#FF0000",
                "#008000",
                "#0000FF",
                "#FFFF00",
                "#7F0000",
                "#004000",
                "#00007F",
                "#7F7F00",
            ]
            sns.set_palette(sns.color_palette(colors))
            my_plot = sns.barplot(
                x = "StimColor",
                hue="StimColor",
                y="RT",
                data=data,
                capsize=0.1,
                ax=ax,
                order=["Red", "Green", "Blue", "Yellow"],
                palette=["C0", "C1", "C2", "C3"],
                legend=False
            )

            # Calculate the y-axis limits and ticks
            max_RT = int(max(data.groupby(["StimColor"]).RT.mean()) + 50)
            y_max = max_RT + 50
            y_min = 150
            y_ticks = list(range(y_min, y_max + 1, 50))

            # Set the y-axis limits and ticks
            ax.set_ylim(y_min, y_max)
            ax.set_yticks(y_ticks)

            plt.title(f"Mean RT by Stimulus Color, {cond} Condition")
            plt.xlabel("Stimulus Color")
            plt.ylabel("Mean Response Time (ms)")

            plt.tight_layout()

            # fig.savefig(f'choice_{cond}_rt_by_stimcolor.png')

            self.stats_write(my_plot.get_figure())

            # cleanup figures so they can be garbage collected before next run
            plt.close("all")

        except Exception as e:
            self.stats_write(f"Error showing output stats: {e}", color="Red")

    def show_output_stats_2way(self, data: pd.DataFrame):
        try:
            data.query('Accuracy=="CORRECT"', inplace=True)

            colors = [str(vstim)[0] for vstim in self.vstims]
            colors = colors[: self.color_count]

            self.stats_write(
                f"<h4>Choice Task<br>ANOVA Difficulty [Hard, Easy] X StimColor "
                f"{colors}</h4>",
                color="Orange",
            )

            # display table
            try:
                table = data.groupby(["Difficulty", "StimColor"])["RT"].agg(
                    ["mean", "count"]
                )
                table = table.astype(int)
                self.stats_write(table.transpose())
            except Exception as e:
                self.stats_write(
                    f"Not enough data to create means table: {e}", color="Red"
                )

            # display anova results
            try:
                err_msg = "Data must contain both 'Hard' and 'Easy' Difficulty."
                assert len(set(data.Difficulty)) == 2, err_msg
                err_msg = "Data must contain StimColor with at least 2 colors."
                assert len(set(data.StimColor)) >= 2, err_msg
                err_msg = (
                    "Data must contain at least 4 RunIDs from at least 2 "
                    "separate runs of 'Easy' Difficulty, and at least 2 separate"
                    " runs of 'Hard' Difficulty."
                )
                assert len(set(data.RunID)) >= 4, err_msg

                aov = pg.mixed_anova(
                    data,
                    dv="RT",
                    subject="RunID",
                    between="Difficulty",
                    within="StimColor",
                )

                # this is cosmetic for demo devices -- helps anova fit in smaller window
                for factor in ("p-GG-corr", "eps", "sphericity", "W-spher", "p-spher"):
                    if factor in aov.columns:
                        aov.drop([factor], axis=1, inplace=True)

                self.stats_write(aov)
            except AssertionError as e:
                self.stats_write(
                    f"Not enough data to run mixed-model anova: {e}", color="Red"
                )
            except Exception as e:
                self.stats_write(f"Unable to run mixed-model anova: {e}", color="Red")

            # create nice bar plot
            # note: this is more vebose than most figures, but I had to do lots of
            #       extra stuff to get different palettes for the 2 rows of bars.
            sns.set(style="whitegrid", color_codes=True)
            sns.set_context("notebook", font_scale=1.5)  # paper, notebook, talk, poster
            fig, ax = plt.subplots(figsize=(7, 5), dpi=96)
            my_plot = sns.barplot(
                x="StimColor",
                y="RT",
                hue="Difficulty",
                hue_order=("hard", "easy"),
                palette={"easy": "grey", "hard": "black"},
                data=data,
                capsize=0.1,
                ax=ax,
            )
            for bar_group, desaturate_value in zip(ax.containers, (0.4, 1)):
                for bar, color in zip(
                    bar_group, ("crimson", "limegreen", "dodgerblue", "yellow")
                ):
                    bar.set_facecolor(sns.desaturate(color, desaturate_value))

            ax.legend(
                handles=[tuple(bar_group) for bar_group in ax.containers],
                labels=[bar_group.get_label() for bar_group in ax.containers],
                title=ax.legend_.get_title().get_text(),
                handlelength=4,
                handler_map={tuple: HandlerTuple(ndivide=None, pad=0.1)},
            )

            plt.title("Mean RT by Difficulty and Stimulus Color")
            plt.xlabel("Stimulus Color")
            plt.ylabel("Mean Response Time (ms)")
            sns.despine()
            plt.tight_layout()

            self.stats_write(my_plot.get_figure())

            # cleanup figures so they can be garbage collected before next run
            plt.close("all")

        except Exception as e:
            self.stats_write(f"Error showing output stats: {e}", color="Red")

    def __getattr__(self, name):
        def _missing(*args, **kwargs):
            print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
            print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
            print("A missing method was called.")
            print(f"The object was {self}, the method was {name}. ")
            print(f"It was called with {args} and {kwargs} as arguments\n")

        return _missing