"""
Graph and statistics generation for choice task device.

This module is independent of pyepiclib - it only reads data from CSV files
and returns an HTML string report.
"""

import base64
import io
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import pingouin as pg
import seaborn as sns
from matplotlib.legend_handler import HandlerTuple

# NOTE: This is so matplotlib doesn't go into gui mode
plt.switch_backend("Agg")


@dataclass
class GraphOptions:
    """Options controlling graph and analysis output."""

    color_count: int = 4
    vstims: tuple = ("Red", "Green", "Blue", "Yellow")


def _fig_to_base64_png(fig, dpi=150) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=dpi, bbox_inches="tight", facecolor="white")
    buf.seek(0)
    b64 = base64.b64encode(buf.read()).decode("ascii")
    buf.close()
    return b64


def _simplify_aov(aov):
    """Remove verbose columns from ANOVA output for cleaner display."""
    for factor in ("p-GG-corr", "eps", "sphericity", "W-spher", "p-spher"):
        if factor in aov.columns:
            aov.drop([factor], axis=1, inplace=True)


def _generate_stats_1way(data: pd.DataFrame, options: GraphOptions) -> list[str]:
    """Generate 1-way ANOVA stats and graphs."""
    output: list[str] = []

    try:
        data = data.copy()
        data.query('Accuracy=="CORRECT"', inplace=True)

        colors = [str(vstim)[0] for vstim in options.vstims]
        colors = colors[: options.color_count]

        cond = str(data["Difficulty"].iloc[0]).title() if len(data) > 0 else "Unknown"

        output.append(
            f'<h4><font color="orange">Choice Task<br>ANOVA: RT by StimColor<br>{colors}<br>"{cond}" Condition.</font></h4>'
        )

        # display table
        try:
            table = data.groupby(["StimColor"])["RT"].agg(["mean", "count"])
            table = table.astype(int)
            output.append(table.transpose().to_html(classes="stats-table", border=0))
        except Exception as e:
            output.append(f"Not enough data to create means table: {e}")

        # display anova results
        try:
            err_msg = "Data must contain StimColor with at least 2 colors."
            assert len(set(data.StimColor)) >= 2, err_msg
            err_msg = "For an ANOVA, the data must contain at least 3 RunIDs from at least 3 separate runs."
            assert len(set(data.RunID)) >= 3, err_msg

            aov = pg.rm_anova(data, dv="RT", subject="RunID", within="StimColor")
            _simplify_aov(aov)
            output.append(aov.to_html(index=False, float_format="%.3f", classes="stats-table", border=0))
        except AssertionError as e:
            output.append(f"Not enough data to run mixed-model anova: {e}")
        except Exception as e:
            output.append(f"Unable to run mixed-model anova: {e}")

        # create bar plot
        fig, ax = plt.subplots(figsize=(7, 4), dpi=96)
        sns.set_theme(style="whitegrid", color_codes=True)
        sns.set_context("paper", font_scale=1.5)
        colors_palette = [
            "#FF0000",
            "#008000",
            "#0000FF",
            "#FFFF00",
            "#7F0000",
            "#004000",
            "#00007F",
            "#7F7F00",
        ]
        sns.set_palette(sns.color_palette(colors_palette))
        my_plot = sns.barplot(
            x="StimColor",
            y="RT",
            data=data,
            capsize=0.1,
            ax=ax,
            order=["Red", "Green", "Blue", "Yellow"],
        )

        highest_mean = int(max(data.groupby(["StimColor"]).RT.mean()) + 50)
        my_plot.set_ylim(150, highest_mean)
        ticks = list(range(150, highest_mean, 50))

        my_plot.set_yticks(ticks)
        my_plot.set_yticklabels(ticks)
        plt.title(f'Mean RT by Stimulus Color, "{cond}" Condition')
        plt.xlabel("Stimulus Color")
        plt.ylabel("Mean Response Time (ms)")

        img_b64 = _fig_to_base64_png(fig)
        output.append(
            f"""
            <div class="figure">
            <img src="data:image/png;base64,{img_b64}" alt="Choice RT Plot">
            </div>
            """
        )

        plt.close("all")

    except Exception as e:
        output.append(f'<font color="red"><h4>Error showing output stats [1]: {str(e)}</h4></font>')

    return output


def _generate_stats_2way(data: pd.DataFrame, options: GraphOptions) -> list[str]:
    """Generate 2-way ANOVA stats and graphs (Difficulty x StimColor)."""
    output: list[str] = []

    try:
        data = data.copy()
        data.query('Accuracy=="CORRECT"', inplace=True)

        colors = [str(vstim)[0] for vstim in options.vstims]
        colors = colors[: options.color_count]

        output.append(f'<h4><font color="orange">Choice Task<br>ANOVA Difficulty [Hard, Easy] X StimColor {colors}</font></h4>')

        # display table
        try:
            table = data.groupby(["Difficulty", "StimColor"])["RT"].agg(["mean", "count"])
            table = table.astype(int)
            output.append(table.transpose().to_html(classes="stats-table", border=0))
        except Exception as e:
            output.append(f"Not enough data to create means table: {e}")

        # display anova results
        try:
            err_msg = "Data must contain both 'Hard' and 'Easy' Difficulty."
            assert len(set(data.Difficulty)) == 2, err_msg
            err_msg = "Data must contain StimColor with at least 2 colors."
            assert len(set(data.StimColor)) >= 2, err_msg
            err_msg = (
                "Data must contain at least 4 RunIDs from at least 2 "
                "separate runs of 'Easy' Difficulty, and at least 2 separate"
                " runs of 'Hard' Difficulty."
            )
            assert len(set(data.RunID)) >= 4, err_msg

            aov = pg.mixed_anova(
                data,
                dv="RT",
                subject="RunID",
                between="Difficulty",
                within="StimColor",
            )
            _simplify_aov(aov)
            output.append(aov.to_html(index=False, float_format="%.3f", classes="stats-table", border=0))
        except AssertionError as e:
            output.append(f"Not enough data to run mixed-model anova: {e}")
        except Exception as e:
            output.append(f"Unable to run mixed-model anova: {e}")

        # create bar plot with difficulty hue
        sns.set_theme(style="whitegrid", color_codes=True)
        sns.set_context("notebook", font_scale=1.5)
        fig, ax = plt.subplots(figsize=(7, 5), dpi=96)
        _ = sns.barplot(
            x="StimColor",
            y="RT",
            hue="Difficulty",
            hue_order=("hard", "easy"),
            palette={"easy": "grey", "hard": "black"},
            data=data,
            capsize=0.1,
            ax=ax,
        )
        for bar_group, desaturate_value in zip(ax.containers, (0.4, 1)):
            for bar, color in zip(bar_group, ("crimson", "limegreen", "dodgerblue", "yellow")):
                bar.set_facecolor(sns.desaturate(color, desaturate_value))

        ax.legend(
            handles=[tuple(bar_group) for bar_group in ax.containers],
            labels=["Hard", "Easy"],
            title=ax.legend_.get_title().get_text(),
            handlelength=4,
            handler_map={tuple: HandlerTuple(ndivide=None, pad=0.1)},
        )

        plt.title("Mean RT by Difficulty and Stimulus Color")
        plt.xlabel("Stimulus Color")
        plt.ylabel("Mean Response Time (ms)")
        sns.despine()
        plt.tight_layout()

        img_b64 = _fig_to_base64_png(fig)
        output.append(
            f"""
            <div class="figure">
            <img src="data:image/png;base64,{img_b64}" alt="Choice RT 2-way Plot">
            </div>
            """
        )

        plt.close("all")

    except Exception as e:
        output.append(f"Error showing output stats [2]: {str(e)}")

    return output


def make_graphs(
    header: str,
    data_root: Path,
    options: GraphOptions | None = None,
) -> str:
    """Generate HTML report with graphs and statistics.

    Args:
        header: HTML header string to prepend to the report
        data_root: Path to directory containing data_output.csv
        options: Graph generation options (uses defaults if None)

    Returns:
        HTML string containing the full report
    """
    if options is None:
        options = GraphOptions()

    pd.set_option("display.precision", 3)

    output: list[str] = [header] if header else []

    # Load data
    data_file = Path(data_root, "data_output.csv")
    if not data_file.exists():
        output.append(f'<font color="red">Data file not found: {data_file}</font>')
        return "\n".join(output)

    data = pd.read_csv(data_file)

    # Summary stats
    correct_data = data.query('Accuracy=="CORRECT"')
    correct_trials_n = len(correct_data.Accuracy)
    all_trials_n = len(data.Accuracy)
    mean_rt = correct_data.RT.mean() if correct_trials_n else None
    accuracy = ((correct_trials_n / all_trials_n) * 100) if all_trials_n else 0

    output.append(
        f"N={all_trials_n}, \n"
        f"CORRECT={correct_trials_n} \n"
        f"INCORRECT={all_trials_n - correct_trials_n} \n"
        f"MEAN_RT={'NA' if mean_rt is None else int(mean_rt)} \n"
        f"ACCURACY={accuracy:0.2f}% \n"
        f"DATA_FILE={data_file}"
    )

    # Generate appropriate stats based on data
    if "Difficulty" in data.columns and sorted(set(data["Difficulty"])) == ["easy", "hard"]:
        output.extend(_generate_stats_2way(data, options))
    else:
        output.extend(_generate_stats_1way(data, options))

    return "\n".join(output)


if __name__ == "__main__":
    import tempfile
    import webbrowser

    data_root = Path(__file__).parent
    try:
        html = make_graphs(header="", data_root=data_root)
        with tempfile.NamedTemporaryFile(mode="w", suffix=".html", delete=False) as f:
            f.write(html)
            webbrowser.open(f"file://{f.name}")
    except Exception as e:
        print(f"Error generating graphs: {e}")
